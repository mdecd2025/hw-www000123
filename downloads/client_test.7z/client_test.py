import websocket
import json
import keyboard  # For capturing key presses
import time

class WebotsController:
    def __init__(self, server_ip, server_port):
        self.server_ip = server_ip
        self.server_port = server_port
        self.ws = None  # WebSocket connection
        self.last_direction = None  # Last direction command sent

    def connect(self):
        """Establish WebSocket connection."""
        if not self.ws:
            ws_url = f"ws://[{self.server_ip}]:{self.server_port}"
            self.ws = websocket.create_connection(ws_url)
            print("Connected to Webots server.")

    def send_command(self, direction):
        """Send control command to the robot."""
        if self.ws and direction != self.last_direction:
            message = json.dumps({"direction": direction})
            self.ws.send(message)
            print(f"Sent command: {direction}")
            self.last_direction = direction

    def close(self):
        """Close the WebSocket connection."""
        if self.ws:
            self.ws.close()
            print("Connection closed.")
            self.ws = None


def main():
    """Listen for arrow key presses and send commands."""
    server_ip = "2001:288:6004:17:fff1:cd25:0:b011"  # Replace with the Webots server's IPv6 address
    server_port = 1234  # Port
    controller = WebotsController(server_ip, server_port)
    
    print("Use arrow keys to control the robot (UP, DOWN, LEFT, RIGHT). Press 'ESC' to quit.")

    while True:
        try:
            # Establish connection if no active connection
            if not controller.ws:
                controller.connect()

            # Detect key presses
            if keyboard.is_pressed("up"):
                controller.send_command("UP")
            elif keyboard.is_pressed("down"):
                controller.send_command("DOWN")
            elif keyboard.is_pressed("left"):
                controller.send_command("LEFT")
            elif keyboard.is_pressed("right"):
                controller.send_command("RIGHT")
            else:
                # If no key is pressed, send stop command and close connection
                if controller.ws:
                    controller.send_command("STOP")

            # Exit the loop if 'ESC' is pressed
            if keyboard.is_pressed("esc"):
                print("Exiting...")
                break

            # Small delay to reduce CPU usage
            time.sleep(0.05)

        except Exception as e:
            print(f"Error: {e}")
            break


if __name__ == "__main__":
    main()
