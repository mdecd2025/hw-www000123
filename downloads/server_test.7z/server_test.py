import threading
import json
import socket
import time
from websocket_server import WebsocketServer
from controller import Robot, Keyboard as WebotsKeyboard
import keyboard

# 常量
TIME_STEP = 32
WHEEL_RADIUS = 0.1
L = 0.471
W = 0.376
MAX_VELOCITY = 10.0

# 初始化机器人
robot = Robot()

# 初始化 Webots 键盘
webots_keyboard = WebotsKeyboard()
webots_keyboard.enable(TIME_STEP)

# 获取电机设备
wheel1 = robot.getDevice("wheel1")
wheel2 = robot.getDevice("wheel2")
wheel3 = robot.getDevice("wheel3")
wheel4 = robot.getDevice("wheel4")

# 将电机设置为速度控制模式
for wheel in [wheel1, wheel2, wheel3, wheel4]:
    wheel.setPosition(float('inf'))
    wheel.setVelocity(0)

def set_wheel_velocity(v1, v2, v3, v4):
    """设置所有电机的速度"""
    wheel1.setVelocity(v1)
    wheel2.setVelocity(v2)
    wheel3.setVelocity(v3)
    wheel4.setVelocity(v4)

# 自定义 WebSocket 服务器类，支持 IPv6
class IPv6WebsocketServer(WebsocketServer):
    def __init__(self, host, port):
        self.address_family = socket.AF_INET6  # 启用 IPv6
        super().__init__(host=host, port=port)

# WebSocket 消息处理函数
def on_message(client, server, message):
    """处理 WebSocket 消息，控制机器人"""
    try:
        data = json.loads(message)  # 解析消息
        direction = data.get("direction")

        if direction == "UP":
            velocity = MAX_VELOCITY
            set_wheel_velocity(velocity, velocity, velocity, velocity)
        elif direction == "DOWN":
            velocity = -MAX_VELOCITY
            set_wheel_velocity(velocity, velocity, velocity, velocity)
        elif direction == "LEFT":
            velocity = MAX_VELOCITY
            set_wheel_velocity(-velocity, velocity, -velocity, velocity)
        elif direction == "RIGHT":
            velocity = MAX_VELOCITY
            set_wheel_velocity(velocity, -velocity, velocity, -velocity)
        elif direction == "STOP":
            set_wheel_velocity(0, 0, 0, 0)
    except json.JSONDecodeError:
        print("收到无效消息。期望 JSON 格式。")
    except Exception as e:
        print(f"处理消息时发生错误: {e}")

# WebSocket 服务器线程
def start_websocket_server():
    """启动 WebSocket 服务器以接收控制消息"""
    server_ip = "2001:288:6004:17:fff1:cd25:0:b011"  # 请替换为 Webots 服务器的 IPv6 地址
    server_port = 1234  # 监听端口
    
    try:
        server = IPv6WebsocketServer(host=server_ip, port=server_port)
        server.set_fn_message_received(on_message)
        print(f"WebSocket 服务器已启动，地址为 [{server_ip}]:{server_port}，等待命令...")
        server.run_forever()
    except Exception as e:
        print(f"启动 WebSocket 服务器失败: {e}")

# 键盘控制线程
def start_arrow_key_control():
    """监听箭头键按下事件来控制机器人"""
    print("使用箭头键控制机器人（上、下、左、右）。按 'ESC' 键退出。")
    while True:
        try:
            if keyboard.is_pressed("up"):
                print("箭头键: 上")
                set_wheel_velocity(MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY)
            elif keyboard.is_pressed("down"):
                print("箭头键: 下")
                set_wheel_velocity(-MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY)
            elif keyboard.is_pressed("left"):
                print("箭头键: 左")
                set_wheel_velocity(-MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY)
            elif keyboard.is_pressed("right"):
                print("箭头键: 右")
                set_wheel_velocity(MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY)
            elif keyboard.is_pressed("esc"):
                print("退出箭头键控制...")
                set_wheel_velocity(0, 0, 0, 0)
                break
            time.sleep(0.1)  # 添加小延迟，避免占用过多 CPU
        except Exception as e:
            print(f"箭头键控制发生错误: {e}")
            break

# Webots 仿真线程
def start_webots_simulation():
    """运行 Webots 仿真循环"""
    try:
        while robot.step(TIME_STEP) != -1:
            # 如果需要，可以在这里添加额外的仿真逻辑
            time.sleep(TIME_STEP / 1000.0)  # 每个仿真步长后休眠，保持一致的仿真速度
    except Exception as e:
        print(f"仿真发生错误: {e}")

# 主函数
if __name__ == "__main__":
    # 创建 Webots 仿真、WebSocket 服务器和箭头键控制的线程
    websocket_thread = threading.Thread(target=start_websocket_server, daemon=True)
    simulation_thread = threading.Thread(target=start_webots_simulation, daemon=True)
    arrow_key_thread = threading.Thread(target=start_arrow_key_control, daemon=True)

    # 启动线程
    websocket_thread.start()
    simulation_thread.start()
    arrow_key_thread.start()

    # 保持主线程存活
    try:
        while True:
            time.sleep(1)  # 让主线程休眠，减少 CPU 使用率
    except KeyboardInterrupt:
        print("正在优雅地关闭程序...")
